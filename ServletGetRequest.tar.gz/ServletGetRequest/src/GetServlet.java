import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doGet(req, resp);
		String flavour = req.getParameter("flavour").toLowerCase();
		System.out.println("flavour="+flavour);
		switch(flavour){
			case "vanilla" : req.setAttribute("message", "You have ordered Vanilla");
							 req.getRequestDispatcher("output.jsp").forward(req, resp);
				break;
			case "strawberry" : req.setAttribute("message", "You have ordered StrawBerry");
			 					req.getRequestDispatcher("output.jsp").forward(req, resp);
				break;
			default : req.setAttribute("message", "Sorry, "+flavour+" not available");
					  req.getRequestDispatcher("output.jsp").forward(req, resp);
				break;
		}
		
	}
}
