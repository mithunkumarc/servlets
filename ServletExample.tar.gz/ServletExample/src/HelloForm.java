import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloForm extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		String firstName = req.getParameter("first_name");
		String lastName = req.getParameter("last_name");
		System.out.println("first name="+firstName);
		System.out.println("last name="+lastName);
		
		req.setAttribute("first_name", firstName);
		req.setAttribute("last_name", lastName);
		req.getRequestDispatcher("display.jsp").forward(req, resp);
	}
}
