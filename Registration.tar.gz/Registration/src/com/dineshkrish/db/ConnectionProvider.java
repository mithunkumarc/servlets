package com.dineshkrish.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class ConnectionProvider {

	private static Connection connection;

	public static Connection getConnection() {

		try {

			// Loading Driver Class
			Class.forName("com.mysql.jdbc.Driver");

			// Getting the Connection
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Test", "root", "root");

		} catch (ClassNotFoundException e) {

			System.out.println(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {

			System.out.println(e.getMessage());
			e.printStackTrace();
		}

		return connection;
	}
}
/*table create statement*/
/*CREATE TABLE student_details(firstName varchar(30), secondName varchar(30), age int, emailId varchar(50), dob date, contactNumber varchar(12), qualification varchar(30), address varchar(100));*/



